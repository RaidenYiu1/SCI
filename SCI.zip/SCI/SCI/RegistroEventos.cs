﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCI
{
	public static class RegistroEventos
	{
		public static List<string> Eventos { get; } = new List<string>();

		public static void Registrar(string texto)
		{
			string evento = $"[{DateTime.Now}] {texto}";
			Eventos.Add(evento);
		}
	}
}

