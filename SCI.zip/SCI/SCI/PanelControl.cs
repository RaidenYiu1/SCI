﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SCI.Class1;

namespace SCI
{
    public class PanelControl
	{
		public Sensor[] Sensores { get; }
		private Random random = new Random();

		public PanelControl()
		{
			Sensores = new Sensor[]
			{
				new SensorHumo(1),
				new SensorTemperatura(2),
				new SensorHumo(3)
			};
		}

		public void MostrarSensores()
		{
			Console.WriteLine("=== ESTADO DE SENSORES ===");
			foreach (var s in Sensores)
			{
				Console.WriteLine($"ID {s.Id} - {s.Nombre} | Lectura: {s.Lectura} | Estado: {s.Estado}");
			}
		}

		public void SimularLecturas()
		{
			foreach (var s in Sensores)
			{
				int valor = random.Next(0, 120);
				s.SimularLectura(valor);
			}

			RegistroEventos.Registrar("Simulación de lectura ejecutada.");
		}

		public void ActivarAlarmaManual(int id)
		{
			var s = Sensores.FirstOrDefault(x => x.Id == id);
			if (s == null) return;

			s.ActivarAlarma();
		}

		public void ResetearSensor(int id)
		{
			var s = Sensores.FirstOrDefault(x => x.Id == id);
			if (s == null) return;

			s.Resetear();
		}

		public void DesactivarSensor(int id)
		{
			var s = Sensores.FirstOrDefault(x => x.Id == id);
			if (s == null) return;

			s.Desactivar();
		}

		public void MostrarHistorial()
		{
			Console.WriteLine("=== HISTORIAL DE EVENTOS ===");
			foreach (var e in RegistroEventos.Eventos)
				Console.WriteLine(e);
		}
	}
}