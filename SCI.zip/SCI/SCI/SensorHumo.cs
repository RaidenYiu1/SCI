﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SCI.Class1;

namespace SCI
{
	public class SensorHumo : Sensor
	{
		public SensorHumo(int id) : base(id, "Sensor de Humo", 50)
		{
		}
	}
}
