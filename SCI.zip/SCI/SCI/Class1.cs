﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCI
{
    public class Class1
    {
		public enum EstadoSensor
		{
			Normal,
			Alarma,
			Desactivado
		}

		public abstract class Sensor
		{
			public int Id { get; }
			public string Nombre { get; }
			public int Umbral { get; protected set; }
			public int Lectura { get; protected set; }
			public EstadoSensor Estado { get; protected set; }

			public Sensor(int id, string nombre, int umbral)
			{
				Id = id;
				Nombre = nombre;
				Umbral = umbral;
				Estado = EstadoSensor.Normal;
			}

			public virtual void SimularLectura(int valor)
			{
				if (Estado == EstadoSensor.Desactivado)
				{
					RegistroEventos.Registrar($"Intento de lectura en sensor DESACTIVADO: {Nombre}");
					return;
				}

				Lectura = valor;

				if (Lectura >= Umbral)
					ActivarAlarma();
				else
				{
					Estado = EstadoSensor.Normal;
					RegistroEventos.Registrar($"Lectura normal: {Nombre} = {Lectura}");
				}
			}

			public virtual void ActivarAlarma()
			{
				Estado = EstadoSensor.Alarma;
				RegistroEventos.Registrar($"¡¡ALERTA!! Sensor {Nombre} (ID {Id}) en ALARMA");

				// beep fuerte
				for (int i = 0; i < 2; i++)
				{
					Console.Beep(1000, 200);
					Console.Beep(1200, 200);
				}
			}

			public void Resetear()
			{
				Estado = EstadoSensor.Normal;
				RegistroEventos.Registrar($"Sensor {Nombre} reseteado");

				Console.Beep(500, 100); // beep suave
			}

			public void Desactivar()
			{
				Estado = EstadoSensor.Desactivado;
				RegistroEventos.Registrar($"Sensor {Nombre} desactivado");

				Console.Beep(400, 100); // beep suave grave
			}
		}
	}
}

